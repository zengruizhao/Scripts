This file is meant for explaining the usage of "SuperpixelSegmentation.exe"


DISCLAIMER:
Please use it at your own risk. The executable is provided only for the purpose of evalualtion of the algorithm presented in the paper "SLIC Superpixels". Neither the authors of the paper nor EPFL can be held responsible for any damages resulting from use of this software.

USAGE:

[1] Input a required number of superpixels in the edit box. This number should be greater than 1 and less than the total number of pixels in the image.

[2] Change the default value of the spatial distance weight if needed.

[3] Click on "Start"

[4] Choose one or more images.

[5] Choose the folder where to save the segmented image showing superpixel boundaries.


As output, the algorithm generates two files:
- the segmented file showing boundaries overlaid on the original image
- a filename.dat file which contains labels of the segments.

INFO ON filename.data
---------------------

This is a binary file containing the label of each pixel (as a 32 bit integer value) in raster scan order with no other characters (like spaces or commas).

They can be read in C using the following function (or something similar):

	//------------------------------------------------------
	FILE* pf = fopen("C:/userchosenpath/filename.dat", "r");
	int sz = width*height;
	int* vals = new int[sz];
	int elread = fread((char*)vals, sizeof(int), sz, pf);
	for( int j = 0; j < height; j++ )
	{
		for( int k = 0; k < width; k++ )
		{
			int i = j*width+k;
			labels[i] = vals[i];
		}
	}
	delete [] vals;
	fclose(pf);
	//------------------------------------------------------


In this function, width and height of the image are provided as input. labels is an array that contains the labels in raster scan order.




